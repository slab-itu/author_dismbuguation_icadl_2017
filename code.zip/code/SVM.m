   
 % read excel file for SVM classification
filename = 'Coded_File_classification_allfeatures.xlsx';
%filename = 'coded_features.xlsx';
%filename = 'Coded_File.xlsx';
%A = xlsread(filename,'','','basic');
A = xlsread(filename);
%A = csvread(filename,',','r');

row=size(A,1);                      % total rows
label = size(A,2);                  % last column for class
p=randperm(row);                    % to divide data randomly
tr= floor(row*0.7);                 % take 70 percent data as training  
traindata= A(p(1:tr),(1:label));    % training data rows
testdata=A(p(tr+1:row),(1:label));  % test data rows

trainlabel=traindata(:,label);      % labels of train data
testlabel=testdata(:,label);        % labels of test data

train= A(p(1:tr),(1:label-1));      % train data
test=A(p(tr+1:row),(1:label-1));    % test data

prob=[];

num_classes = length(unique(trainlabel));

for class_ind = 1:num_classes
    
    %train an SVM for each class
    class_train = 2*(trainlabel == class_ind)-1;    %positive = 1, negative = -1
    class_test = 2*(testlabel == class_ind)-1;      %positive = 1, negative = -1
 
    SVMStruct = svmtrain(class_train,train, '-s 0 -c 1.0 -g 0.001 -t 0 -h 0');     %SVM train
    
    %Group = svmclassify(SVMStruct,test);
    [label,~,p]= svmpredict(class_test,test,SVMStruct);
    prob=[prob p];
    
end

[~,pred_label] = max(prob, [], 2);

% 
% Compute Accuracy -
predicted_tag=pred_label;
reference_tag=testlabel;
C=predicted_tag-reference_tag;
Correct=sum(C(:)==0);
Acc=(Correct/length(predicted_tag))*100
 confMat=confusionmat(reference_tag,predicted_tag);
% Eval = Evaluate(reference_tag,predicted_tag);


precision1 = diag(confMat) ./ sum(confMat,2);
precision=mean(precision1)*100

  recall1 = diag(confMat) ./ sum(confMat,1)';
recall=mean(recall1)*100