%# read the whole file to a temporary cell array
%fid = fopen('array_of_keywords.txt','r');
%fid = fopen('coauthor_list.txt','r');
%tmp = textscan(fid,'%s','delimiter','\n');
%fclose(fid);                        %You can get the first line as tmp{1}{1}, the second as tmp{1}{2}

%----------------- for cell array -----------------------------------------
%  fid = fopen('array_of_keywords.txt','r');   %# Open the file
 fid = fopen('sourcetitilearray.txt','r');  
%  lineArray = cell(11679,1);     %# Preallocate a cell array (ideally slightly
 lineArray = cell(1813,1); 
                               %#   larger than is needed)
  lineIndex = 1;               %# Index of cell to place the next line in
  nextLine = fgetl(fid);       %# Read the first line from the file
  while ~isequal(nextLine,-1)         %# Loop while not at the end of the file
    lineArray{lineIndex} = nextLine;  %# Add the line to the cell array
    lineIndex = lineIndex+1;          %# Increment the line index
    nextLine = fgetl(fid);            %# Read the next line from the file   lineArray(i,j) , lineArray(i,1)
  end
  fclose(fid); 

  
 %
%A = xlsread('lower_author_keywords.xlsx')
 %[~,txt,~] = xlsread('lower_author_keywords.xlsx');     %txt(:,:) to access row and col
 [~,txt,~] = xlsread('source_title.xlsx');  

  

 % map of keys and keywords -----------------------------------------------
 map = containers.Map('KeyType','char','ValueType','int32');
key=1:numel(lineArray);
  for k = 1 : numel(lineArray)
     % disp(sprintf('%d = ',k));
     map(lineArray{k}) = key(k);
  end
    
 
%keyword = map('');

%values(map);
 %keyword=txt(1,1)

%valueSet = values(map,keyword)

% matrix=zeros(length(txt),length(lineArray)); 
matrix=zeros(length(txt),1); 
 
for i = 1 : length(txt)
   for j = 1 : 1          %5 columns for keywords, 10 for co authors
       keySet = txt(i,j);
      
       if (isKey(map,keySet)==1)
            valueSet = values(map,keySet);
            col_value=cell2mat(valueSet);
            % disp(sprintf('%d = ',col_value));
             % matrix(i,col_value)=1;
            matrix(i,j)=col_value;
        
       end
      % if (isKey(map,keySet)==0)
       %       matrix(i,j)=0;
      %end
          
   end
end

csvwrite('coded_sourcetitle.csv',matrix);